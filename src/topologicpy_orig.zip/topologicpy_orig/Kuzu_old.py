from __future__ import annotations

import contextlib
import json
import os
import threading
import time
import warnings
from typing import Any, Dict, List, Optional

try:
    import kuzu
except Exception:
    print("Kuzu - Installing required kuzu library.")
    try:
        os.system("pip install kuzu")
    except Exception:
        os.system("pip install kuzu --user")
    try:
        import kuzu
    except Exception:
        warnings.warn("Kuzu - Error: Could not import Kuzu.")
        kuzu = None


# -----------------------------------------------------------------------------
# Internal helpers
# -----------------------------------------------------------------------------


def _json_dumps(value: Any) -> str:
    """Return a JSON string, falling back to string conversion for non-serializable values."""
    try:
        return json.dumps(value if value is not None else {}, ensure_ascii=False)
    except Exception:
        try:
            return json.dumps(_make_json_safe(value), ensure_ascii=False)
        except Exception:
            return "{}"


def _json_loads(value: Any, default: Any = None) -> Any:
    """Load JSON safely."""
    if default is None:
        default = {}
    if value is None:
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value)
    except Exception:
        return default


def _make_json_safe(value: Any) -> Any:
    """Convert common non-JSON values to JSON-safe values."""
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _make_json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_make_json_safe(v) for v in value]
    return str(value)


def _rows(result: Any) -> List[Dict[str, Any]]:
    """Normalize Kuzu result objects to a list of row dictionaries."""
    if result is None:
        return []
    try:
        return result.rows_as_dict().get_all()
    except Exception:
        pass
    try:
        return result.get_all()
    except Exception:
        pass
    if isinstance(result, list):
        return result
    return []


def _value_from_dict(dictionary: Any, key: str = None, default: Any = None) -> Any:
    """Read from a TopologicPy dictionary safely."""
    if key is None:
        return default
    try:
        from topologicpy.Dictionary import Dictionary
        return Dictionary.ValueAtKey(dictionary, key, default)
    except Exception:
        try:
            return dictionary.get(key, default)
        except Exception:
            return default


def _python_dictionary(dictionary: Any) -> Dict[str, Any]:
    """Convert a TopologicPy dictionary to a Python dict safely."""
    if dictionary is None:
        return {}
    if isinstance(dictionary, dict):
        return dict(dictionary)
    try:
        from topologicpy.Dictionary import Dictionary
        d = Dictionary.PythonDictionary(dictionary)
        return dict(d or {})
    except Exception:
        return {}


def _normalize_label(label: Any) -> str:
    """Return a normalized string label for query parameters and outputs."""
    if label is None:
        return ""
    return str(label).strip()


def _unique_preserve_order(values: List[Any]) -> List[Any]:
    seen = set()
    out = []
    for v in values or []:
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


class _DBCache:
    """
    One kuzu.Database per path. Thread-safe and process-local.
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._cache: Dict[str, "kuzu.Database"] = {}

    def get(self, path: str) -> "kuzu.Database":
        if kuzu is None:
            raise RuntimeError("Kuzu - Error: Kuzu is not available.")
        if path is None:
            raise ValueError("Kuzu - Error: The input path is None.")
        path = os.path.abspath(os.path.expanduser(str(path)))
        with self._lock:
            db = self._cache.get(path)
            if db is None:
                db = kuzu.Database(path)
                self._cache[path] = db
            return db


class _WriteGate:
    """
    Serialize writes to avoid IO lock contention.
    """

    def __init__(self):
        self._lock = threading.RLock()

    @contextlib.contextmanager
    def hold(self):
        with self._lock:
            yield


_db_cache = _DBCache()
_write_gate = _WriteGate()


class _ConnectionPool:
    """
    Per-thread kuzu.Connection pool bound to a Database instance.
    """

    def __init__(self, db: "kuzu.Database"):
        self.db = db
        self._local = threading.local()

    def _ensure(self) -> "kuzu.Connection":
        if not hasattr(self._local, "conn"):
            self._local.conn = kuzu.Connection(self.db)
        return self._local.conn

    @contextlib.contextmanager
    def connection(self, write: bool = False):
        conn = self._ensure()
        if write:
            with _write_gate.hold():
                yield conn
        else:
            yield conn


class _Mgr:
    """
    Lightweight facade providing read/write execution and schema bootstrap.
    """

    def __init__(self, db_path: str):
        self.db_path = os.path.abspath(os.path.expanduser(str(db_path)))
        self._db = _db_cache.get(self.db_path)
        self._pool = _ConnectionPool(self._db)

    @contextlib.contextmanager
    def read(self):
        with self._pool.connection(write=False) as c:
            yield c

    @contextlib.contextmanager
    def write(self):
        with self._pool.connection(write=True) as c:
            yield c

    def exec(self, query: str, params: Optional[dict] = None, write: bool = False, retries: int = 5, backoff: float = 0.15):
        params = params or {}
        attempt = 0
        while True:
            try:
                with (self.write() if write else self.read()) as c:
                    res = c.execute(query, parameters=params)
                    try:
                        with res:
                            return _rows(res)
                    except Exception:
                        return _rows(res)
            except Exception:
                attempt += 1
                if (not write) or attempt > retries:
                    raise
                time.sleep(backoff * attempt)

    def ensure_schema(self):
        self.exec(
            """
            CREATE NODE TABLE IF NOT EXISTS Graph(
                id STRING,
                label STRING,
                num_nodes INT64,
                num_edges INT64,
                props STRING,
                PRIMARY KEY(id)
            );
            """,
            write=True,
        )
        self.exec(
            """
            CREATE NODE TABLE IF NOT EXISTS Vertex(
                id STRING,
                graph_id STRING,
                label STRING,
                x DOUBLE,
                y DOUBLE,
                z DOUBLE,
                props STRING,
                PRIMARY KEY(id)
            );
            """,
            write=True,
        )
        self.exec(
            """
            CREATE REL TABLE IF NOT EXISTS Edge(FROM Vertex TO Vertex, label STRING, props STRING);
            """,
            write=True,
        )


class Kuzu:
    # -------------------------------------------------------------------------
    # Core: database, connection, schema
    # -------------------------------------------------------------------------

    @staticmethod
    def EnsureSchema(manager, silent: bool = False) -> bool:
        """
        Ensures the required Kùzu schema exists in the input database manager.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if successful, False otherwise.
        """
        try:
            manager.ensure_schema()
            return True
        except Exception as e:
            if not silent:
                print(f"Kuzu.EnsureSchema - Error: {e}. Returning False.")
            return False

    @staticmethod
    def Database(path: str, silent: bool = False):
        """
        Returns the underlying kuzu.Database instance for the input path.

        Parameters
        ----------
        path : str
            Path to the Kùzu database. It will be created if it does not exist.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        kuzu.Database
            The Kùzu database found at the path.
        """
        try:
            return _db_cache.get(path)
        except Exception as e:
            if not silent:
                print(f"Kuzu.Database - Error: {e}. Returning None.")
            return None

    @staticmethod
    def Connection(manager, silent: bool = False):
        """
        Returns a kuzu.Connection bound to the input manager.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        kuzu.Connection
            A live Kùzu connection. Do not share it across threads.
        """
        try:
            return manager._pool._ensure()
        except Exception as e:
            if not silent:
                print(f"Kuzu.Connection - Error: {e}. Returning None.")
            return None

    @staticmethod
    def Manager(path: str, silent: bool = False):
        """
        Returns a lightweight manager bound to the database at the input path.

        Parameters
        ----------
        path : str
            Path to the Kùzu database. It will be created if it does not exist.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        Kuzu.Manager
            The Kùzu manager.
        """
        try:
            return _Mgr(path)
        except Exception as e:
            if not silent:
                print(f"Kuzu.Manager - Error: {e}. Returning None.")
            return None

    # -------------------------------------------------------------------------
    # Graph persistence
    # -------------------------------------------------------------------------

    @staticmethod
    def UpsertGraph(graphDB,
                    graph,
                    mantissa: int = 6,
                    silent: bool = False) -> str:
        """
        Upserts a TopologicPy graph into Kuzu using the canonical schema.

        Parameters
        ----------
        graphDB: dict
            The graph database descriptor. See GraphDB.ByParameters(...).
        graph: topologic_core.Graph
            The graph to be upserted.
        mantissa : int , optional
            The number of decimal places to use when extracting mesh data. Default is 6.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        str
            The graph id used, or None on error.
        """
        try:
            from topologicpy.Graph import Graph
            from topologicpy.Topology import Topology

            options = graphDB.get("options", None)

            if not options == None:

                manager = graphDB.get("manager")
                graphIDKey = graphDB.get("graphIDKey")
                overwrite = graphDB.get("overwrite", False)
                bidirectional = graphDB.get("bidirectional", True)
                vertexIDKey = graphDB.get("vertexIDKey", "vertex_id")
                vertexLabelKey = graphDB.get("vertexLabelKey", None)
                defaultVertexLabel = graphDB.get("defaultVertexLabel", "Node")
                vertexCategoryKey = graphDB.get("vertexCategoryKey", None)
                defaultVertexCategory = graphDB.get("defaultVertexCategory", "Node")
                edgeLabelKey = graphDB.get("edgeLabelKey", None)
                defaultEdgeLabel = graphDB.get("defaultEdgeLabel", "CONNECTED_TO")
                edgeCategoryKey = graphDB.get("edgeCategoryKey", None)
                defaultEdgeCategory = graphDB.get("defaultEdgeCategory", "Edge")

                manager.ensure_schema()

                graph_dict = Topology.Dictionary(graph)
                gid = _value_from_dict(graph_dict, graphIDKey, None) if graphIDKey is not None else None
                if gid is None or str(gid).strip() == "":
                    gid = Topology.UUID(graph)
                gid = str(gid).strip()

                # Check if graph already exists.
                exists_rows = manager.exec(
                    """
                    MATCH (g:Graph)
                    WHERE g.id = $gid
                    RETURN COUNT(g) > 0 AS exists;
                    """,
                    {"gid": gid},
                    write=False,
                ) or []

                exists = False
                if exists_rows:
                    try:
                        exists = bool(exists_rows[0].get("exists"))
                    except Exception:
                        exists = False

                if exists and not overwrite:
                    if not silent:
                        print("Kuzu.UpsertGraph - Error: The graph already exists and overwrite is False. Returning None.")
                    return None

                g_props = _python_dictionary(graph_dict)
                g_label = str(g_props.get("label", ""))

                mesh_data = Graph.MeshData(graph, mantissa=mantissa)
                verts = mesh_data.get("vertices", [])
                v_props = mesh_data.get("vertexDictionaries", [])
                edges = mesh_data.get("edges", [])
                e_props = mesh_data.get("edgeDictionaries", [])

                num_nodes = len(verts)
                num_edges = len(edges) * (2 if bidirectional else 1)

                # Delete prior data for this graph id. Edges must be deleted before vertices.
                if exists and overwrite:
                    manager.exec(
                        """
                        MATCH (a:Vertex)-[r:Edge]->(b:Vertex)
                        WHERE a.graph_id = $gid AND b.graph_id = $gid
                        DELETE r;
                        """,
                        {"gid": gid},
                        write=True,
                    )
                    manager.exec("MATCH (v:Vertex) WHERE v.graph_id = $gid DELETE v;", {"gid": gid}, write=True)
                    manager.exec("MATCH (g:Graph) WHERE g.id = $gid DELETE g;", {"gid": gid}, write=True)

                manager.exec(
                    """
                    CREATE (g:Graph {id:$id, label:$label, num_nodes:$num_nodes, num_edges:$num_edges, props:$props});
                    """,
                    {
                        "id": gid,
                        "label": g_label,
                        "num_nodes": int(num_nodes),
                        "num_edges": int(num_edges),
                        "props": _json_dumps(g_props),
                    },
                    write=True,
                )

                vertex_ids = []
                for i, xyz in enumerate(verts):
                    props = dict(v_props[i] or {}) if i < len(v_props) else {}
                    x, y, z = xyz

                    raw_vid = props.get(vertexIDKey, i) if vertexIDKey is not None else i
                    raw_vid = str(raw_vid).strip()

                    # Kuzu Vertex.id is a global primary key, so scope it by graph id.
                    # Preserve the original vertex id in props under vertexIDKey.
                    vid = raw_vid
                    if not vid.startswith(f"{gid}:"):
                        vid = f"{gid}:{raw_vid}"

                    if vertexIDKey is not None:
                        props[vertexIDKey] = raw_vid
                    props["_db_id"] = vid
                    props["graph_id"] = gid

                    label = props.get(vertexLabelKey, None) if vertexLabelKey is not None else None
                    if label is None or str(label).strip() == "":
                        label = defaultVertexLabel if defaultVertexLabel is not None else str(i)
                    label = str(label).strip()

                    if vertexCategoryKey is not None:
                        category = props.get(vertexCategoryKey, defaultVertexCategory)
                        if category is not None:
                            props[vertexCategoryKey] = category

                    vertex_ids.append(vid)

                    manager.exec(
                        """
                        CREATE (v:Vertex {id:$id, graph_id:$gid, label:$label, props:$props, x:$x, y:$y, z:$z});
                        """,
                        {
                            "id": vid,
                            "gid": gid,
                            "label": label,
                            "x": float(x),
                            "y": float(y),
                            "z": float(z),
                            "props": _json_dumps(props),
                        },
                        write=True,
                    )

                for i, edge_indices in enumerate(edges):
                    try:
                        a_index = int(edge_indices[0])
                        b_index = int(edge_indices[1])
                    except Exception:
                        continue

                    if (
                        a_index < 0 or
                        b_index < 0 or
                        a_index >= len(vertex_ids) or
                        b_index >= len(vertex_ids)
                    ):
                        continue

                    props = dict(e_props[i] or {}) if i < len(e_props) else {}

                    label = props.get(edgeLabelKey, None) if edgeLabelKey is not None else None
                    if label is None or str(label).strip() == "":
                        label = props.get("type", None)
                    if label is None or str(label).strip() == "":
                        label = defaultEdgeLabel
                    label = str(label).strip()

                    if edgeLabelKey is not None:
                        props[edgeLabelKey] = label

                    if edgeCategoryKey is not None:
                        category = props.get(edgeCategoryKey, defaultEdgeCategory)
                        if category is not None:
                            props[edgeCategoryKey] = category

                    a_id = vertex_ids[a_index]
                    b_id = vertex_ids[b_index]

                    manager.exec(
                        """
                        MATCH (a:Vertex {id:$a}), (b:Vertex {id:$b})
                        CREATE (a)-[:Edge {label:$label, props:$props}]->(b);
                        """,
                        {
                            "a": a_id,
                            "b": b_id,
                            "label": label,
                            "props": _json_dumps(props),
                        },
                        write=True,
                    )

                    if bidirectional and a_id != b_id:
                        manager.exec(
                            """
                            MATCH (a:Vertex {id:$a}), (b:Vertex {id:$b})
                            CREATE (a)-[:Edge {label:$label, props:$props}]->(b);
                            """,
                            {
                                "a": b_id,
                                "b": a_id,
                                "label": label,
                                "props": _json_dumps(props),
                            },
                            write=True,
                        )

                return gid

        except Exception as e:
            if not silent:
                print(f"Kuzu.UpsertGraph - Error: {e}. Returning None.")
            return None

    @staticmethod
    def GraphByID(manager, graphID: str, silent: bool = False):
        """
        Constructs a TopologicPy graph from Kùzu using the input graph id.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        graphID : str
            The graph id to retrieve from Kùzu.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Graph
            A new TopologicPy graph, or None on error.
        """
        try:
            from topologicpy.Graph import Graph
            from topologicpy.Dictionary import Dictionary
            from topologicpy.Vertex import Vertex
            from topologicpy.Edge import Edge
            from topologicpy.Topology import Topology

            manager.ensure_schema()
            graphID = str(graphID)

            rows_g = manager.exec(
                """
                MATCH (g:Graph)
                WHERE g.id = $id
                RETURN g.id AS id, g.label AS label, g.num_nodes AS num_nodes, g.num_edges AS num_edges, g.props AS props;
                """,
                {"id": graphID},
                write=False,
            ) or []
            if not rows_g:
                return None

            g_row = rows_g[0]
            g_props = dict(_json_loads(g_row.get("props"), {}))
            if "label" not in g_props and g_row.get("label") is not None:
                g_props["label"] = g_row.get("label")
            g_dict = Dictionary.ByPythonDictionary(g_props)

            rows_v = manager.exec(
                """
                MATCH (v:Vertex)
                WHERE v.graph_id = $gid
                RETURN v.id AS id, v.label AS label, v.x AS x, v.y AS y, v.z AS z, v.props AS props
                ORDER BY v.id;
                """,
                {"gid": graphID},
                write=False,
            ) or []

            id_to_vertex = {}
            vertices = []
            for row in rows_v:
                x = row.get("x") if row.get("x") is not None else 0.0
                y = row.get("y") if row.get("y") is not None else 0.0
                z = row.get("z") if row.get("z") is not None else 0.0
                v = Vertex.ByCoordinates(float(x), float(y), float(z))
                props = dict(_json_loads(row.get("props"), {}))
                if "id" not in props:
                    props["id"] = row.get("id")
                if "label" not in props:
                    props["label"] = row.get("label") or ""
                d = Dictionary.ByPythonDictionary(props)
                v = Topology.SetDictionary(v, d)
                id_to_vertex[row["id"]] = v
                vertices.append(v)

            rows_e = manager.exec(
                """
                MATCH (a:Vertex)-[r:Edge]->(b:Vertex)
                WHERE a.graph_id = $gid AND b.graph_id = $gid
                RETURN a.id AS a_id, b.id AS b_id, r.label AS label, r.props AS props;
                """,
                {"gid": graphID},
                write=False,
            ) or []

            edges = []
            for row in rows_e:
                va = id_to_vertex.get(row.get("a_id"))
                vb = id_to_vertex.get(row.get("b_id"))
                if va is None or vb is None:
                    continue
                e = Edge.ByStartVertexEndVertex(va, vb)
                props = dict(_json_loads(row.get("props"), {}))
                if "label" not in props:
                    props["label"] = row.get("label") or "connect"
                d = Dictionary.ByPythonDictionary(props)
                e = Topology.SetDictionary(e, d)
                edges.append(e)

            if not vertices:
                return None
            g = Graph.ByVerticesEdges(vertices, edges)
            g = Topology.SetDictionary(g, g_dict)
            return g
        except Exception as e:
            if not silent:
                print(f"Kuzu.GraphByID - Error: {e}. Returning None.")
            return None

    @staticmethod
    def GraphsByQuery(manager, query: str, params: dict = None, silent: bool = False):
        """
        Executes a Kùzu Cypher query and returns a list of TopologicPy graphs.

        The query should return either a graph_id column or one of the common id
        fields from which a graph id can be inferred.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        query : str
            A valid Kùzu Cypher query.
        params : dict , optional
            Parameters to pass with the query.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            A list of reconstructed TopologicPy graphs.
        """
        try:
            manager.ensure_schema()
            rows = manager.exec(query, params or {}, write=False) or []
            gids = []
            for row in rows:
                gid = row.get("graph_id") or row.get("gid")
                if gid is None:
                    for key in ("a_id", "b_id", "id", "vertex_id"):
                        value = row.get(key)
                        if isinstance(value, str) and ":" in value:
                            gid = value.split(":", 1)[0]
                            break
                if gid is not None and gid not in gids:
                    gids.append(gid)

            graphs = []
            for gid in gids:
                g = Kuzu.GraphByID(manager, str(gid), silent=silent)
                if g is not None:
                    graphs.append(g)
            return graphs
        except Exception as e:
            if not silent:
                print(f"Kuzu.GraphsByQuery - Error: {e}. Returning None.")
            return None

    @staticmethod
    def DeleteGraph(manager, graphID: str, silent: bool = False) -> bool:
        """
        Deletes a graph by id.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        graphID : str
            The graph id to delete.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True on success, False otherwise.
        """
        try:
            manager.ensure_schema()
            graphID = str(graphID)
            manager.exec(
                """
                MATCH (a:Vertex)-[r:Edge]->(b:Vertex)
                WHERE a.graph_id = $gid AND b.graph_id = $gid
                DELETE r;
                """,
                {"gid": graphID},
                write=True,
            )
            manager.exec("MATCH (v:Vertex) WHERE v.graph_id = $gid DELETE v;", {"gid": graphID}, write=True)
            manager.exec("MATCH (g:Graph) WHERE g.id = $gid DELETE g;", {"gid": graphID}, write=True)
            return True
        except Exception as e:
            if not silent:
                print(f"Kuzu.DeleteGraph - Error: {e}. Returning False.")
            return False

    @staticmethod
    def EmptyDatabase(manager, dropSchema: bool = False, recreateSchema: bool = True, silent: bool = False) -> bool:
        """
        Empties the Kùzu database.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        dropSchema : bool , optional
            If True, drops the known tables. Default is False.
        recreateSchema : bool , optional
            If True and dropSchema is True, recreates the schema after dropping. Default is True.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True on success, False otherwise.
        """
        try:
            if dropSchema:
                for stmt in [
                    "DROP TABLE IF EXISTS Edge;",
                    "DROP TABLE IF EXISTS Vertex;",
                    "DROP TABLE IF EXISTS Graph;",
                ]:
                    try:
                        manager.exec(stmt, write=True)
                    except Exception as e:
                        if not silent:
                            print(f"Kuzu.EmptyDatabase - Warning: {e}")
                if recreateSchema:
                    manager.ensure_schema()
                return True

            manager.ensure_schema()
            manager.exec("MATCH (a)-[r]->(b) DELETE r;", write=True)
            manager.exec("MATCH (v:Vertex) DELETE v;", write=True)
            manager.exec("MATCH (g:Graph) DELETE g;", write=True)
            return True
        except Exception as e:
            if not silent:
                print(f"Kuzu.EmptyDatabase - Error: {e}. Returning False.")
            return False

    @staticmethod
    def ListGraphs(manager, where: dict = None, limit: int = 100, offset: int = 0, silent: bool = False) -> list[dict]:
        """
        Lists graph metadata with simple filtering and pagination.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        where : dict , optional
            Supported filters: id, label, props_contains, props_equals, min_nodes,
            max_nodes, min_edges, max_edges.
        limit : int , optional
            Maximum number of records to return. Default is 100.
        offset : int , optional
            Number of records to skip. Default is 0.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            A list of graph metadata dictionaries.
        """
        try:
            manager.ensure_schema()
            where = where or {}
            conds = []
            params = {}

            if where.get("id"):
                conds.append("g.id = $id")
                params["id"] = str(where["id"])
            if where.get("label"):
                conds.append("g.label CONTAINS $label_sub")
                params["label_sub"] = str(where["label"])
            if where.get("props_contains"):
                conds.append("g.props CONTAINS $props_sub")
                params["props_sub"] = str(where["props_contains"])
            if where.get("props_equals"):
                conds.append("g.props = $props_equals")
                params["props_equals"] = str(where["props_equals"])
            if where.get("min_nodes") is not None:
                conds.append("g.num_nodes >= $min_nodes")
                params["min_nodes"] = int(where["min_nodes"])
            if where.get("max_nodes") is not None:
                conds.append("g.num_nodes <= $max_nodes")
                params["max_nodes"] = int(where["max_nodes"])
            if where.get("min_edges") is not None:
                conds.append("g.num_edges >= $min_edges")
                params["min_edges"] = int(where["min_edges"])
            if where.get("max_edges") is not None:
                conds.append("g.num_edges <= $max_edges")
                params["max_edges"] = int(where["max_edges"])

            where_clause = ("WHERE " + " AND ".join(conds)) if conds else ""
            params["offset"] = max(0, int(offset or 0))
            params["limit"] = max(0, int(limit or 100))
            return manager.exec(
                f"""
                MATCH (g:Graph)
                {where_clause}
                RETURN g.id AS id, g.label AS label, g.num_nodes AS num_nodes, g.num_edges AS num_edges, g.props AS props
                ORDER BY g.id
                SKIP $offset LIMIT $limit;
                """,
                params,
                write=False,
            ) or []
        except Exception as e:
            if not silent:
                print(f"Kuzu.ListGraphs - Error: {e}. Returning None.")
            return None

    # -------------------------------------------------------------------------
    # CSV import: Graph.ByCSVPath -> Kuzu.UpsertGraph
    # -------------------------------------------------------------------------

    @staticmethod
    def ByCSVPath(
        manager,
        path,
        graphIDHeader="graph_id", graphLabelHeader="label", graphFeaturesHeader="feat", graphFeaturesKeys=None,
        edgeSRCHeader="src_id", edgeDSTHeader="dst_id", edgeLabelHeader="label",
        edgeTrainMaskHeader="train_mask", edgeValidateMaskHeader="val_mask", edgeTestMaskHeader="test_mask",
        edgeFeaturesHeader="feat", edgeFeaturesKeys=None,
        nodeIDHeader="node_id", nodeLabelHeader="label",
        nodeTrainMaskHeader="train_mask", nodeValidateMaskHeader="val_mask", nodeTestMaskHeader="test_mask",
        nodeFeaturesHeader="feat", nodeXHeader="X", nodeYHeader="Y", nodeZHeader="Z",
        nodeFeaturesKeys=None,
        tolerance=0.0001, silent=False):
        """
        Reads CSV graph data using Graph.ByCSVPath and upserts all returned graphs into Kùzu.

        The method mirrors the Graph.ByCSVPath signature and delegates CSV parsing to
        Graph.ByCSVPath. Each returned graph is then persisted with Kuzu.UpsertGraph.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        path : str
            The CSV dataset path accepted by Graph.ByCSVPath.
        graphIDHeader : str , optional
            The graph id column/header. Default is "graph_id".
        graphLabelHeader : str , optional
            The graph label column/header. Default is "label".
        graphFeaturesHeader : str , optional
            The graph features prefix/header. Default is "feat".
        graphFeaturesKeys : list , optional
            Optional graph feature keys. Default is None.
        edgeSRCHeader : str , optional
            The edge source id column/header. Default is "src_id".
        edgeDSTHeader : str , optional
            The edge destination id column/header. Default is "dst_id".
        edgeLabelHeader : str , optional
            The edge label column/header. Default is "label".
        edgeTrainMaskHeader : str , optional
            The edge train mask column/header. Default is "train_mask".
        edgeValidateMaskHeader : str , optional
            The edge validation mask column/header. Default is "val_mask".
        edgeTestMaskHeader : str , optional
            The edge test mask column/header. Default is "test_mask".
        edgeFeaturesHeader : str , optional
            The edge features prefix/header. Default is "feat".
        edgeFeaturesKeys : list , optional
            Optional edge feature keys. Default is None.
        nodeIDHeader : str , optional
            The node id column/header. Default is "node_id".
        nodeLabelHeader : str , optional
            The node label column/header. Default is "label".
        nodeTrainMaskHeader : str , optional
            The node train mask column/header. Default is "train_mask".
        nodeValidateMaskHeader : str , optional
            The node validation mask column/header. Default is "val_mask".
        nodeTestMaskHeader : str , optional
            The node test mask column/header. Default is "test_mask".
        nodeFeaturesHeader : str , optional
            The node features prefix/header. Default is "feat".
        nodeXHeader : str , optional
            The node X-coordinate column/header. Default is "X".
        nodeYHeader : str , optional
            The node Y-coordinate column/header. Default is "Y".
        nodeZHeader : str , optional
            The node Z-coordinate column/header. Default is "Z".
        nodeFeaturesKeys : list , optional
            Optional node feature keys. Default is None.
        tolerance : float , optional
            The tolerance passed to Graph.ByCSVPath. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        dict
            A dictionary containing the number of upserted graphs and their ids.
        """
        try:
            from topologicpy.Graph import Graph

            manager.ensure_schema()
            graphs = Graph.ByCSVPath(
                path=path,
                graphIDHeader=graphIDHeader, graphLabelHeader=graphLabelHeader,
                graphFeaturesHeader=graphFeaturesHeader, graphFeaturesKeys=graphFeaturesKeys,
                edgeSRCHeader=edgeSRCHeader, edgeDSTHeader=edgeDSTHeader, edgeLabelHeader=edgeLabelHeader,
                edgeTrainMaskHeader=edgeTrainMaskHeader, edgeValidateMaskHeader=edgeValidateMaskHeader,
                edgeTestMaskHeader=edgeTestMaskHeader, edgeFeaturesHeader=edgeFeaturesHeader,
                edgeFeaturesKeys=edgeFeaturesKeys,
                nodeIDHeader=nodeIDHeader, nodeLabelHeader=nodeLabelHeader,
                nodeTrainMaskHeader=nodeTrainMaskHeader, nodeValidateMaskHeader=nodeValidateMaskHeader,
                nodeTestMaskHeader=nodeTestMaskHeader, nodeFeaturesHeader=nodeFeaturesHeader,
                nodeXHeader=nodeXHeader, nodeYHeader=nodeYHeader, nodeZHeader=nodeZHeader,
                nodeFeaturesKeys=nodeFeaturesKeys,
                tolerance=tolerance, silent=silent)

            if graphs is None:
                if not silent:
                    print("Kuzu.ByCSVPath - Error: Graph.ByCSVPath returned None. Returning None.")
                return None
            if not isinstance(graphs, list):
                graphs = [graphs]

            graph_ids = []
            for graph in graphs:
                gid = Kuzu.UpsertGraph(
                    manager,
                    graph,
                    graphIDKey=graphIDHeader,
                    vertexIDKey=nodeIDHeader,
                    vertexLabelKey=nodeLabelHeader,
                    silent=silent)
                if gid is not None:
                    graph_ids.append(gid)

            return {"graphs_upserted": len(graph_ids), "graph_ids": graph_ids}
        except Exception as e:
            if not silent:
                print(f"Kuzu.ByCSVPath - Error: {e}. Returning None.")
            return None

    # -------------------------------------------------------------------------
    # Corpus analytics for graph generation / GraphRAG workflows
    # -------------------------------------------------------------------------

    @staticmethod
    def FetchAllPairs(manager, undirected: bool = True, silent: bool = False) -> list:
        """
        Returns all labelled adjacency pairs found in the Kùzu graph corpus.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        undirected : bool , optional
            If True, pairs are normalized so A-B and B-A are counted together. Default is True.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            A list of dictionaries with a_label, b_label, count, and optionally pair.
        """
        try:
            manager.ensure_schema()
            rows = manager.exec(
                """
                MATCH (a:Vertex)-[r:Edge]->(b:Vertex)
                RETURN a.label AS a_label, b.label AS b_label, COUNT(*) AS count
                ORDER BY count DESC;
                """,
                write=False,
            ) or []

            if not undirected:
                return rows

            counts = {}
            for row in rows:
                a = _normalize_label(row.get("a_label"))
                b = _normalize_label(row.get("b_label"))
                if a == "" or b == "":
                    continue
                key = tuple(sorted([a, b]))
                counts[key] = counts.get(key, 0) + int(row.get("count") or 0)

            out = []
            for (a, b), count in sorted(counts.items(), key=lambda item: (-item[1], item[0][0], item[0][1])):
                out.append({"a_label": a, "b_label": b, "pair": [a, b], "count": count})
            return out
        except Exception as e:
            if not silent:
                print(f"Kuzu.FetchAllPairs - Error: {e}. Returning None.")
            return None

    @staticmethod
    def MaxNeighborsForLabel(manager, label: str, silent: bool = False) -> int:
        """
        Returns the maximum observed degree for vertices with the input label.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        label : str
            The vertex label to inspect.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        int
            The maximum observed number of neighbours for the input label.
        """
        try:
            manager.ensure_schema()
            label = _normalize_label(label)
            if label == "":
                return 0

            rows = manager.exec(
                """
                MATCH (v:Vertex)
                WHERE v.label = $label
                OPTIONAL MATCH (v)-[r1:Edge]->(o1:Vertex)
                RETURN v.id AS id, COUNT(o1) AS out_degree;
                """,
                {"label": label},
                write=False,
            ) or []

            # Kùzu versions vary in support for OPTIONAL MATCH aggregation. Add inbound counts separately.
            in_rows = manager.exec(
                """
                MATCH (o2:Vertex)-[r2:Edge]->(v:Vertex)
                WHERE v.label = $label
                RETURN v.id AS id, COUNT(o2) AS in_degree;
                """,
                {"label": label},
                write=False,
            ) or []

            degree_by_id = {}
            for row in rows:
                vid = row.get("id")
                if vid is not None:
                    degree_by_id[vid] = degree_by_id.get(vid, 0) + int(row.get("out_degree") or 0)
            for row in in_rows:
                vid = row.get("id")
                if vid is not None:
                    degree_by_id[vid] = degree_by_id.get(vid, 0) + int(row.get("in_degree") or 0)
            return max(degree_by_id.values()) if degree_by_id else 0
        except Exception as e:
            if not silent:
                print(f"Kuzu.MaxNeighborsForLabel - Error: {e}. Returning 0.")
            return 0

    @staticmethod
    def CandidateCountsForLabels(manager, labels, excludeLabels=None, limit: int = 50, silent: bool = False) -> list:
        """
        Returns candidate neighbour labels ranked by corpus frequency.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        labels : list or str
            The existing labels in the working graph. Candidate labels are counted from
            corpus adjacencies involving these labels.
        excludeLabels : list , optional
            Candidate labels to exclude, typically labels already present if duplicates
            are not desired. Default is None.
        limit : int , optional
            Maximum number of candidates to return. Default is 50.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            A ranked list of dictionaries with label, count, and attach_to_labels.
        """
        try:
            manager.ensure_schema()

            if isinstance(labels, str):
                labels = [labels]

            labels = [_normalize_label(x) for x in (labels or []) if _normalize_label(x) != ""]
            labels = _unique_preserve_order(labels)

            exclude = [_normalize_label(x) for x in (excludeLabels or []) if _normalize_label(x) != ""]
            exclude = _unique_preserve_order(exclude)

            # Case-insensitive comparison lists.
            labels_lc = _unique_preserve_order([str(x).lower() for x in labels])
            exclude_lc = _unique_preserve_order([str(x).lower() for x in exclude])
            exclude_set = set(exclude_lc)

            if not labels_lc:
                return []

            counts = {}
            attach_to = {}

            rows_out = manager.exec(
                """
                MATCH (a:Vertex)-[r:Edge]->(b:Vertex)
                WITH
                    LOWER(COALESCE(a.label, "")) AS attach_label,
                    LOWER(COALESCE(b.label, "")) AS candidate_label
                WHERE attach_label IN $labels
                RETURN attach_label, candidate_label, COUNT(*) AS count;
                """,
                {"labels": labels_lc},
                write=False,
            ) or []

            rows_in = manager.exec(
                """
                MATCH (a:Vertex)-[r:Edge]->(b:Vertex)
                WITH
                    LOWER(COALESCE(b.label, "")) AS attach_label,
                    LOWER(COALESCE(a.label, "")) AS candidate_label
                WHERE attach_label IN $labels
                RETURN attach_label, candidate_label, COUNT(*) AS count;
                """,
                {"labels": labels_lc},
                write=False,
            ) or []

            for row in rows_out + rows_in:
                candidate = _normalize_label(row.get("candidate_label"))
                source = _normalize_label(row.get("attach_label"))

                candidate_lc = str(candidate).lower()
                source_lc = str(source).lower()

                if candidate_lc == "" or candidate_lc in exclude_set:
                    continue

                count = int(row.get("count") or 0)

                counts[candidate_lc] = counts.get(candidate_lc, 0) + count

                if candidate_lc not in attach_to:
                    attach_to[candidate_lc] = {}

                attach_to[candidate_lc][source_lc] = attach_to[candidate_lc].get(source_lc, 0) + count

            out = []
            max_items = max(0, int(limit or 50))

            for label, count in sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:max_items]:
                ranked_attach = sorted(
                    attach_to.get(label, {}).items(),
                    key=lambda item: (-item[1], item[0])
                )

                out.append({
                    "label": label,
                    "count": count,
                    "attach_to_labels": [x[0] for x in ranked_attach],
                    "attach_to_counts": dict(ranked_attach),
                })

            return out

        except Exception as e:
            if not silent:
                print(f"Kuzu.CandidateCountsForLabels - Error: {e}. Returning None.")
            return None

    @staticmethod
    def FindBestExampleForLabel(manager, label: str, attachTo: str = None, silent: bool = False) -> dict:
        """
        Finds a representative corpus vertex for the input label.

        If attachTo is supplied, preference is given to examples connected to that
        neighbouring label. The result includes graph id, vertex id, label, coordinates,
        degree, neighbour labels, and props.

        Parameters
        ----------
        manager : Kuzu.Manager
            The Kùzu database manager.
        label : str
            The label to find.
        attachTo : str , optional
            A preferred adjacent label. Default is None.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        dict
            Information about the best example, or None on error/not found.
        """
        try:
            manager.ensure_schema()
            label = _normalize_label(label)
            attachTo = _normalize_label(attachTo) if attachTo is not None else None
            if label == "":
                return None

            if attachTo:
                rows = manager.exec(
                    """
                    MATCH (v:Vertex)-[r:Edge]->(n:Vertex)
                    WHERE v.label = $label AND n.label = $attach
                    RETURN v.id AS id, v.graph_id AS graph_id, v.label AS label, v.x AS x, v.y AS y, v.z AS z, v.props AS props, COUNT(n) AS score
                    ORDER BY score DESC
                    LIMIT 1;
                    """,
                    {"label": label, "attach": attachTo},
                    write=False,
                ) or []
                if not rows:
                    rows = manager.exec(
                        """
                        MATCH (n:Vertex)-[r:Edge]->(v:Vertex)
                        WHERE v.label = $label AND n.label = $attach
                        RETURN v.id AS id, v.graph_id AS graph_id, v.label AS label, v.x AS x, v.y AS y, v.z AS z, v.props AS props, COUNT(n) AS score
                        ORDER BY score DESC
                        LIMIT 1;
                        """,
                        {"label": label, "attach": attachTo},
                        write=False,
                    ) or []
            else:
                rows = []

            if not rows:
                rows = manager.exec(
                    """
                    MATCH (v:Vertex)
                    WHERE v.label = $label
                    RETURN v.id AS id, v.graph_id AS graph_id, v.label AS label, v.x AS x, v.y AS y, v.z AS z, v.props AS props
                    LIMIT 1;
                    """,
                    {"label": label},
                    write=False,
                ) or []

            if not rows:
                return None

            row = rows[0]
            vid = row.get("id")
            neighbour_rows_out = manager.exec(
                """
                MATCH (v:Vertex)-[r:Edge]->(n:Vertex)
                WHERE v.id = $id
                RETURN n.label AS label, COUNT(*) AS count;
                """,
                {"id": vid},
                write=False,
            ) or []
            neighbour_rows_in = manager.exec(
                """
                MATCH (n:Vertex)-[r:Edge]->(v:Vertex)
                WHERE v.id = $id
                RETURN n.label AS label, COUNT(*) AS count;
                """,
                {"id": vid},
                write=False,
            ) or []

            neighbour_counts = {}
            for nrow in neighbour_rows_out + neighbour_rows_in:
                n_label = _normalize_label(nrow.get("label"))
                if n_label == "":
                    continue
                neighbour_counts[n_label] = neighbour_counts.get(n_label, 0) + int(nrow.get("count") or 0)

            neighbours = [x[0] for x in sorted(neighbour_counts.items(), key=lambda item: (-item[1], item[0]))]
            props = dict(_json_loads(row.get("props"), {}))
            return {
                "id": vid,
                "vertex_id": vid,
                "graph_id": row.get("graph_id"),
                "label": row.get("label"),
                "x": row.get("x"),
                "y": row.get("y"),
                "z": row.get("z"),
                "props": props,
                "degree": sum(neighbour_counts.values()),
                "neighbour_labels": neighbours,
                "neighbor_labels": neighbours,
                "neighbour_counts": neighbour_counts,
                "neighbor_counts": neighbour_counts,
            }
        except Exception as e:
            if not silent:
                print(f"Kuzu.FindBestExampleForLabel - Error: {e}. Returning None.")
            return None
