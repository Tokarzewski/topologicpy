# Copyright (C) 2026
# Wassim Jabi <wassim.jabi@gmail.com>
#
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU Affero General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
# details.
#
# You should have received a copy of the GNU Affero General Public License along with
# this program. If not, see <https://www.gnu.org/licenses/>.

# src/topologicpy/IFC.py

from __future__ import annotations
from topologicpy.ifc.exporter import IFCReferenceViewExporter, IFCExportConfig

# Bonsai-derived IFC importer adapted for TopologicPy
# Original Bonsai file copyright (C) 2020, 2021 Dion Moult <dion@thinkmoult.com>
# Adapted with kind permission from the original author.
# Adaptation removes Blender/bpy dependencies and creates TopologicPy topologies.
# This derivative keeps the Bonsai-style IfcOpenShell triangulation path.
# Bonsai is GPL-3.0-or-later; preserve the original licence terms when redistributing.
# TopologicPy is AGPL-3.0-or-later; preserve the original licence terms when redistributing.


import logging
import multiprocessing
import time
import traceback
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any, Optional

import ifcopenshell
import ifcopenshell.geom
import ifcopenshell.ifcopenshell_wrapper as W
import ifcopenshell.util.element
import ifcopenshell.util.placement
import ifcopenshell.util.representation
import ifcopenshell.util.shape
import ifcopenshell.util.unit
import numpy as np

from topologicpy.Topology import Topology
from topologicpy.Dictionary import Dictionary


@dataclass
class IfcImportSettings:
    """
    Minimal Bonsai-like import settings for TopologicPy.

    This intentionally omits Blender UI, collections, materials, viewport,
    arrays, and camera settings. It keeps only the settings needed for IFC
    geometry iteration and TopologicPy conversion.
    """

    input_file: Optional[str] = None
    logger: logging.Logger = field(default_factory=lambda: logging.getLogger("ImportIFC.TopologicPy"))
    geometry_library: str = "opencascade"
    should_use_cpu_multiprocessing: bool = True
    should_load_geometry: bool = True
    deflection_tolerance: float = 0.05
    angular_tolerance: float = 0.5
    element_limit_mode: str = "UNLIMITED"
    element_offset: int = 0
    element_limit: int = 30000
    has_filter: bool = False
    elements: Iterable[ifcopenshell.entity_instance] = field(default_factory=set)
    includeTypes: list[str] = field(default_factory=list)
    excludeTypes: list[str] = field(default_factory=list)
    dictionaryMode: str = "none"  # none, basic, all
    clean: bool = False
    epsilon: float = 0.01
    angTolerance: float = 0.1
    tolerance: float = 0.0001
    silent: bool = False

    @staticmethod
    def factory(input_file: Optional[str] = None, logger: Optional[logging.Logger] = None) -> "IfcImportSettings":
        settings = IfcImportSettings()
        settings.input_file = input_file
        if logger is not None:
            settings.logger = logger
        return settings


class IfcImporter:
    """
    Blender-free Bonsai-style IFC importer for TopologicPy.

    Kept close to Bonsai's high-level flow:

    execute()
    -> load_file()
    -> calculate_unit_scale()
    -> process_context_filter()
    -> process_element_filter()
    -> create_elements()
    -> create_generic_elements()
    -> create_products()
    -> create_product()
    -> create_mesh()

    The important surgical replacement is:

    Bonsai:
        create_mesh(...) -> bpy.types.Mesh
        create_product(...) -> bpy.types.Object with matrix_world

    This adaptation:
        create_mesh(...) -> {'vertices', 'faces', 'edges'}
        create_product(...) -> TopologicPy topology with transformed coordinates
    """

    file: ifcopenshell.file
    elements: set[ifcopenshell.entity_instance]

    def __init__(self, ifc_import_settings: IfcImportSettings):
        self.ifc_import_settings = ifc_import_settings
        self.file: Optional[ifcopenshell.file] = None
        self.elements: set[ifcopenshell.entity_instance] = set()
        self.topologies: list[Any] = []
        self.added_data: dict[int, Any] = {}
        self.meshes: dict[str, dict[str, Any]] = {}
        self.time = 0.0
        self.unit_scale = 1.0
        self.progress = 0
        self.pset_cache: dict[str, dict[str, Any]] = {}
        self.include_set = self._normalise_type_list(ifc_import_settings.includeTypes)
        self.exclude_set = self._normalise_type_list(ifc_import_settings.excludeTypes)
        if self.include_set and self.exclude_set:
            self.exclude_set = {t for t in self.exclude_set if t not in self.include_set}

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    def execute(self) -> list[Any]:
        self.profile_code("Starting import process")
        self.load_file()
        self.profile_code("Loading file")
        self.calculate_unit_scale()
        self.profile_code("Calculate unit scale")
        self.process_context_filter()
        self.profile_code("Process context filter")
        self.process_element_filter()
        self.profile_code("Process element filter")
        self.create_elements()
        self.profile_code("Create elements")
        return self.topologies

    # -------------------------------------------------------------------------
    # Bonsai-style progress / setup methods, simplified.
    # -------------------------------------------------------------------------

    def profile_code(self, message: str) -> None:
        if self.ifc_import_settings.silent:
            return
        if not self.time:
            self.time = time.time()
        print("{} :: {:.2f}".format(message, time.time() - self.time))
        self.time = time.time()

    def load_file(self) -> None:
        if self.file is not None:
            return
        if not self.ifc_import_settings.input_file:
            raise ValueError("IfcImportSettings.input_file is required unless importer.file is assigned before execute().")
        self.ifc_import_settings.logger.info("Loading IFC file %s", self.ifc_import_settings.input_file)
        self.file = ifcopenshell.open(self.ifc_import_settings.input_file)

    def calculate_unit_scale(self) -> None:
        try:
            self.unit_scale = ifcopenshell.util.unit.calculate_unit_scale(self.file)
        except Exception:
            self.unit_scale = 1.0

    def process_context_filter(self) -> None:
        """
        Minimal equivalent of Bonsai context setup.

        Bonsai uses prioritised contexts through tool.Loader. Without Blender, we
        keep the geometry iterator settings simple and let IfcOpenShell choose
        the applicable representation.
        """
        return None

    def process_element_filter(self) -> None:
        if self.ifc_import_settings.has_filter:
            elements = list(self.ifc_import_settings.elements)
        else:
            if self.file.schema in ("IFC2X3", "IFC4"):
                elements = list(self.file.by_type("IfcElement")) + list(self.file.by_type("IfcProxy"))
            else:
                elements = list(self.file.by_type("IfcElement"))

        elements = [e for e in elements if not e.is_a("IfcFeatureElement") or e.is_a("IfcSurfaceFeature")]
        elements = [e for e in elements if self._is_allowed(e.is_a().lower())]

        if self.ifc_import_settings.element_limit_mode == "UNLIMITED":
            self.elements = set(elements)
        else:
            offset = self.ifc_import_settings.element_offset
            limit = offset + self.ifc_import_settings.element_limit
            self.elements = set(elements[offset:limit])

        mode = (self.ifc_import_settings.dictionaryMode or "none").strip().lower()
        if mode in {"all", "pset", "psets", "propertysets", "properties"}:
            self.pset_cache = self._build_ifc_pset_cache(prefix="IFC")

    # -------------------------------------------------------------------------
    # Bonsai geometry import flow, adapted.
    # -------------------------------------------------------------------------

    def create_elements(self) -> None:
        self.create_generic_elements(self.elements)

    def create_generic_elements(self, elements: set[ifcopenshell.entity_instance]) -> None:
        if not self.ifc_import_settings.should_load_geometry:
            for element in elements:
                topology = self.create_product(element, shape=None, mesh=None)
                if topology is not None:
                    self.topologies.append(topology)
            return

        elements = elements.copy()
        products = self.create_products(elements, settings=self.create_settings())
        elements -= products

        # Some IFC elements may have no triangulated body representation. Keep a
        # metadata-only placeholder out of the geometry list by default.
        total = len(elements)
        for i, element in enumerate(elements):
            if i % 250 == 0 and not self.ifc_import_settings.silent:
                print("{} / {} elements without geometry processed ...".format(i, total))
            topology = self.create_product(element, shape=None, mesh=None)
            if topology is not None:
                self.topologies.append(topology)

    def create_settings(self) -> ifcopenshell.geom.main.settings:
        settings = ifcopenshell.geom.settings()

        # Follow Bonsai's triangulation route. Do not request SERIALIZED BREP.
        # Do not set USE_WORLD_COORDS. Bonsai keeps mesh vertices local and
        # applies shape.matrix_world. We bake that matrix into TopologicPy coords.
        try:
            settings.set("dimensionality", W.CURVES_SURFACES_AND_SOLIDS)
        except Exception:
            pass
        try:
            settings.set("apply-default-materials", False)
        except Exception:
            pass
        try:
            settings.set("keep-bounding-boxes", True)
        except Exception:
            pass
        try:
            settings.set("layerset-first", True)
        except Exception:
            pass
        try:
            settings.set("no-wire-intersection-check", True)
        except Exception:
            pass
        try:
            settings.set("deflection-tolerance", self.ifc_import_settings.deflection_tolerance)
        except Exception:
            pass
        try:
            settings.set("angular-tolerance", self.ifc_import_settings.angular_tolerance)
        except Exception:
            pass

        return settings

    def create_products(
        self,
        products: set[ifcopenshell.entity_instance],
        settings: Optional[ifcopenshell.geom.main.settings] = None,
    ) -> set[ifcopenshell.entity_instance]:
        checkpoint = time.time()
        results: set[ifcopenshell.entity_instance] = set()
        if not products:
            return results

        # Bonsai's early return: iterator.initialize takes time.
        if not any(getattr(product, "Representation", None) for product in products):
            return results

        try:
            if self.ifc_import_settings.should_use_cpu_multiprocessing:
                iterator = ifcopenshell.geom.iterator(
                    settings,
                    self.file,
                    multiprocessing.cpu_count(),
                    include=products,
                    geometry_library=self.ifc_import_settings.geometry_library,
                )
            else:
                iterator = ifcopenshell.geom.iterator(
                    settings,
                    self.file,
                    include=products,
                    geometry_library=self.ifc_import_settings.geometry_library,
                )
        except TypeError:
            # Older IfcOpenShell versions may not accept geometry_library.
            if self.ifc_import_settings.should_use_cpu_multiprocessing:
                iterator = ifcopenshell.geom.iterator(settings, self.file, multiprocessing.cpu_count(), include=products)
            else:
                iterator = ifcopenshell.geom.iterator(settings, self.file, include=products)

        valid_file = iterator.initialize()
        if not valid_file:
            return results

        progress = 0
        total = len(products)
        while True:
            progress += 1
            if progress % 250 == 0 and not self.ifc_import_settings.silent:
                print("{} / {} elements processed in {:.2f}s ...".format(progress, total, time.time() - checkpoint))
                checkpoint = time.time()

            shape = iterator.get()
            if shape:
                # Bonsai asserts W.TriangulationElement. We keep this permissive
                # to support minor IfcOpenShell API variations.
                try:
                    product = self.file.by_id(shape.id)
                except Exception:
                    product = None

                if product is not None and self._is_allowed(product.is_a().lower()):
                    topology = self.create_product(product, shape)
                    if topology is not None:
                        self.topologies.append(topology)
                        results.add(product)

            if not iterator.next():
                break

        if not self.ifc_import_settings.silent:
            print("Done creating geometry")
        return results

    def create_product(
        self,
        element: ifcopenshell.entity_instance,
        shape: Optional[ifcopenshell.geom.ShapeElementType] = None,
        mesh: Optional[dict[str, Any]] = None,
    ) -> Any:
        """
        Bonsai creates a Blender object here. This version creates a TopologicPy topology.
        """
        if element is None:
            return None

        self.ifc_import_settings.logger.info("Creating topology for %s", element)

        if mesh is None and shape is not None:
            mesh = self.create_mesh(element, shape)

        if not mesh:
            return None

        vertices = mesh.get("vertices") or []
        faces = mesh.get("faces") or []
        edges = mesh.get("edges") or []

        if not vertices:
            return None

        try:
            topology = Topology.ByGeometry(
                vertices=vertices,
                edges=edges,
                faces=faces,
                tolerance=self.ifc_import_settings.tolerance,
                silent=True,
            )
        except TypeError:
            topology = Topology.ByGeometry(
                vertices=vertices,
                edges=edges,
                faces=faces,
                tolerance=self.ifc_import_settings.tolerance,
            )
        except Exception:
            if not self.ifc_import_settings.silent:
                self.ifc_import_settings.logger.error("Could not create TopologicPy topology for %s", element)
                print(traceback.format_exc())
            return None

        if not Topology.IsInstance(topology, "Topology"):
            return None
        if self.ifc_import_settings.clean:
            clean_faces = False
            clean_edges = False
            t_id = Topology.Type(topology)
            if t_id == 128: # Cluster
                faces = Topology.Faces(topology)
                if len(faces) >= 2:
                    clean_faces = True
                wires = Topology.Wires(topology)
                if len(wires) > 0:
                    clean_edges = True
            elif t_id > 8: # Greater than a single face and less than a cluster
                clean_faces = True
            elif t_id > 2: # Greate than a single edge and less than a Cluster
                clean_edges = True

            t_temp = None    
            if clean_faces:
                t_temp = Topology.RemoveCoplanarFaces(topology,
                                                        epsilon=self.ifc_import_settings.epsilon,
                                                        tolerance=self.ifc_import_settings.tolerance,
                                                        silent=self.ifc_import_settings.silent)
            
            if Topology.IsInstance(t_temp, "Topology"):
                topology = t_temp
            
            t_temp = None
            if clean_edges: # Greater than a single edge
                t_temp = Topology.RemoveCollinearEdges(topology,
                                                        angTolerance=self.ifc_import_settings.angTolerance,
                                                        tolerance=self.ifc_import_settings.tolerance,
                                                        silent=self.ifc_import_settings.silent)
            if Topology.IsInstance(t_temp, "Topology"):
                topology = t_temp
                
        topology = self.assign_dictionary(element, topology)
        self.link_element(element, topology)
        return topology

    def create_mesh(
        self,
        element: ifcopenshell.entity_instance,
        shape: Any,
        cartesian_point_offset: Any = None,
    ) -> Optional[dict[str, Any]]:
        """
        Blender-free adaptation of Bonsai's create_mesh.

        Bonsai:
            verts = ifcopenshell.util.shape.get_vertices(geometry)
            mesh = tool.Loader.convert_geometry_to_mesh(...)
            obj.matrix_world = ifcopenshell.util.shape.get_shape_matrix(shape)

        This adaptation:
            verts = get_vertices(geometry)
            verts = optional cartesian point offset handling
            verts = shape matrix baked into coordinates
            faces/edges = geometry indices
            return {'vertices', 'faces', 'edges', ...}
        """
        try:
            if isinstance(shape, W.TriangulationElement):
                geometry = shape.geometry
            else:
                geometry = shape

            mesh_name = self.get_mesh_name_from_shape(geometry)

            verts = ifcopenshell.util.shape.get_vertices(geometry)
            if verts is None:
                return None
            verts = np.asarray(verts, dtype=float)
            if verts.size == 0:
                return None
            if len(verts.shape) == 1:
                verts = verts.reshape((-1, 3))

            has_cartesian_point_offset = False
            offset = None
            if cartesian_point_offset is False:
                has_cartesian_point_offset = False
            elif cartesian_point_offset is not None:
                offset = np.asarray(cartesian_point_offset, dtype=float)
                verts = verts - offset
                has_cartesian_point_offset = True
            elif self.is_point_far_away(verts[0], is_meters=True):
                # Bonsai shifts far-away geometry close to origin and stores an
                # object transform. Since we bake transforms into coordinates,
                # we keep the offset and add it back through the final matrix.
                # This keeps the code Bonsai-like without losing world placement.
                offset = np.asarray(verts[0], dtype=float)
                verts = verts - offset
                has_cartesian_point_offset = True

            faces = self.get_faces_from_geometry(geometry)
            edges = self.get_edges_from_geometry(geometry) if not faces else []

            # Bonsai stores the matrix on the Blender object. TopologicPy returns
            # standalone geometry, so we bake the matrix into the coordinates.
            if isinstance(shape, W.TriangulationElement):
                matrix = ifcopenshell.util.shape.get_shape_matrix(shape)
            else:
                matrix = np.eye(4)

            if offset is not None:
                # Equivalent to Blender keeping local vertices near origin while
                # the object/world placement restores the offset.
                offset_matrix = np.eye(4)
                offset_matrix[0, 3] = float(offset[0])
                offset_matrix[1, 3] = float(offset[1])
                offset_matrix[2, 3] = float(offset[2])
                matrix = np.asarray(matrix, dtype=float) @ offset_matrix

            vertices = self.transform_vertices(verts, matrix)

            return {
                "name": mesh_name,
                "vertices": vertices,
                "faces": faces,
                "edges": edges,
                "has_cartesian_point_offset": has_cartesian_point_offset,
                "cartesian_point_offset": offset.tolist() if offset is not None else None,
                "ifc_definition_id": getattr(element, "id", lambda: None)(),
                "ios_materials": tuple(getattr(geometry, "materials", []) or []),
                "ios_material_ids": list(getattr(geometry, "material_ids", []) or []),
            }

        except Exception:
            if not self.ifc_import_settings.silent:
                self.ifc_import_settings.logger.error("Could not create mesh for %s", element)
                print(traceback.format_exc())
            return None

    # -------------------------------------------------------------------------
    # Dictionary / metadata insertion.
    # -------------------------------------------------------------------------

    def assign_dictionary(self, element: ifcopenshell.entity_instance, topology: Any) -> Any:
        mode = (self.ifc_import_settings.dictionaryMode or "none").strip().lower()
        if mode == "none":
            return topology

        gid = getattr(element, "GlobalId", None)
        element_dict = {
            "TOPOLOGIC_id": str(Topology.UUID(topology)),
            "TOPOLOGIC_name": getattr(element, "Name", None) or "Untitled",
            "TOPOLOGIC_type": Topology.TypeAsString(topology),
            "IFC_id": element.id(),
            "IFC_global_id": gid or 0,
            "IFC_name": getattr(element, "Name", None) or "Untitled",
            "IFC_type": element.is_a().lower(),
        }

        if mode in {"all", "pset", "psets", "propertysets", "properties"} and gid:
            element_dict.update(self.pset_cache.get(gid, {}))

        try:
            return Topology.SetDictionary(topology, Dictionary.ByPythonDictionary(element_dict))
        except Exception:
            return topology

    def _build_ifc_pset_cache(self, prefix: str = "IFC") -> dict[str, dict[str, Any]]:
        cache: dict[str, dict[str, Any]] = {}

        try:
            rels = self.file.by_type("IfcRelDefinesByProperties")
        except Exception:
            rels = []

        for rel in rels:
            try:
                pdef = getattr(rel, "RelatingPropertyDefinition", None)
                if pdef is None or not pdef.is_a("IfcPropertySet"):
                    continue

                pset_name = self._safe_name(getattr(pdef, "Name", None))
                if not pset_name:
                    continue

                props = getattr(pdef, "HasProperties", None)
                if not props:
                    continue

                flat_props: dict[str, Any] = {}
                for prop in props:
                    try:
                        if not prop.is_a("IfcPropertySingleValue"):
                            continue
                        prop_name = self._safe_name(getattr(prop, "Name", None))
                        if not prop_name:
                            continue
                        nominal = getattr(prop, "NominalValue", None)
                        if nominal is None:
                            continue
                        flat_props[f"{prefix}_{pset_name}_{prop_name}"] = self._safe_value(nominal)
                    except Exception:
                        continue

                if not flat_props:
                    continue

                related_objects = getattr(rel, "RelatedObjects", None)
                if not related_objects:
                    continue

                for obj in related_objects:
                    try:
                        gid = getattr(obj, "GlobalId", None)
                        if not gid:
                            continue
                        cache.setdefault(gid, {}).update(flat_props)
                    except Exception:
                        continue

            except Exception:
                continue

        return cache

    # -------------------------------------------------------------------------
    # Small utility methods replacing Bonsai/Blender helpers.
    # -------------------------------------------------------------------------

    def link_element(self, element: ifcopenshell.entity_instance, topology: Any) -> None:
        self.added_data[element.id()] = topology

    def get_mesh_name_from_shape(self, geometry: Any) -> str:
        try:
            return str(geometry.id)
        except Exception:
            return "mesh"

    def get_faces_from_geometry(self, geometry: Any) -> list[list[int]]:
        faces = getattr(geometry, "faces", None)
        if faces is None:
            return []
        try:
            return [[int(faces[i]), int(faces[i + 1]), int(faces[i + 2])] for i in range(0, len(faces), 3)]
        except Exception:
            return []

    def get_edges_from_geometry(self, geometry: Any) -> list[list[int]]:
        edges = getattr(geometry, "edges", None)
        if edges is None:
            return []
        try:
            return [[int(edges[i]), int(edges[i + 1])] for i in range(0, len(edges), 2)]
        except Exception:
            return []

    def transform_vertices(self, vertices: np.ndarray, matrix: Any) -> list[list[float]]:
        m = np.asarray(matrix, dtype=float)
        if m.shape != (4, 4):
            return vertices.tolist()
        ones = np.ones((vertices.shape[0], 1), dtype=float)
        homogeneous = np.hstack((vertices, ones))
        transformed = homogeneous @ m.T
        return transformed[:, :3].tolist()

    def is_point_far_away(self, point: Any, is_meters: bool = True) -> bool:
        try:
            distance_limit = 1000.0 if is_meters else 1000.0 * self.unit_scale
            p = np.asarray(point, dtype=float)
            return bool(np.linalg.norm(p) > distance_limit)
        except Exception:
            return False

    def get_element_matrix(self, element: ifcopenshell.entity_instance) -> np.ndarray:
        try:
            result = ifcopenshell.util.placement.get_local_placement(element.ObjectPlacement)
        except Exception:
            result = np.eye(4)
        result = np.asarray(result, dtype=float)
        result[0][3] *= self.unit_scale
        result[1][3] *= self.unit_scale
        result[2][3] *= self.unit_scale
        return result

    def _normalise_type_list(self, types: Optional[list[str]]) -> set[str]:
        if types is None:
            return set()
        return {str(t).strip().lower() for t in types if t is not None and str(t).strip()}

    def _is_allowed(self, element_type: str) -> bool:
        if self.include_set and element_type not in self.include_set:
            return False
        if self.exclude_set and element_type in self.exclude_set:
            return False
        return True

    def _safe_name(self, value: Any) -> Optional[str]:
        if value is None:
            return None
        try:
            value = str(value).strip()
            return value if value else None
        except Exception:
            return None

    def _safe_value(self, nominal: Any) -> Any:
        if nominal is None:
            return None
        try:
            return nominal.wrappedValue
        except Exception:
            return None


class IFC:
    @staticmethod
    def TopologiesByFile(
        file,
        includeTypes: list = [],
        excludeTypes: list = [],
        dictionaryMode: str = "basic",
        clean: bool = False,
        epsilon: float = 0.01,
        angTolerance: float = 0.1,
        tolerance: float = 0.0001,
        silent: bool = False,
    ) -> list[Any]:
        """
        Import an IFC file into a list of TopologicPy topologies using the
        Blender-free Bonsai-style triangulation pipeline.

        Parameters
        ----------
        ifc_file : ifcopenshell.file
            The input IFC file object.
        includeTypes : list , optional
            IFC object types to include. Case-insensitive. Default is [].
        excludeTypes : list , optional
            IFC object types to exclude. Case-insensitive. Default is [].
        dictionaryMode : str , optional
            Options are "none", "basic", or "all". Default is "basic".
        clean : bool , optional
            If set to True, coplanar faces and collinear edges are removed. Default is False.
        epsilon : float , optional
            The desired epsilon (another form of tolerance) for finding if two faces are coplanar. Default is 0.01.
        angTolerance : float , optional
            The desired angular tolerance for removing collinear edges. Default is 0.1.
        tolerance : float , optional
            TopologicPy tolerance. Default is 0.0001.
        silent : bool , optional
            If True, warnings and progress messages are suppressed. Default is False.

        Returns
        -------
        list
            The created TopologicPy topologies.
        """
        settings = IfcImportSettings.factory()
        settings.includeTypes = includeTypes
        settings.excludeTypes = excludeTypes
        settings.dictionaryMode = dictionaryMode
        settings.clean = clean
        settings.epsilon = epsilon
        settings.angTolerance = angTolerance
        settings.tolerance = tolerance
        settings.silent = silent

        importer = IfcImporter(settings)

        importer.file = file

        return importer.execute()


    @staticmethod
    def TopologiesByPath(path: str,
                  includeTypes: list = [],
                  excludeTypes: list = [],
                  dictionaryMode: str = "basic",
                  clean: bool = False,
                  epsilon: float = 0.0001,
                  angTolerance: float = 0.1,
                  tolerance: float = 0.0001,
                  silent: bool = False) -> list[Any]:
        """
        Imports the topologies from an IFC file path.

        Parameters
        ----------
        path : str
            The path to the IFC file.
        includeTypes : list , optional
            The list of IFC object types to include. It is case insensitive. If set to an empty list, all types are included. Default is [].
        excludeTypes : list , optional
            The list of IFC object types to exclude. It is case insensitive. If set to an empty list, no types are excluded. Default is [].
        dictionaryMode : str , optional
            Options are "none", "basic", or "all". Default is "basic".
        clean : bool , optional
            If set to True, coplanar faces and collinear edges are removed. Default is False.
        epsilon : float , optional
            The desired epsilon (another form of tolerance) for finding if two faces are coplanar. Default is 0.01.
        angTolerance : float , optional
            The desired angular tolerance for removing collinear edges. Default is 0.1.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The created list of topologies.
        
        """
        import ifcopenshell

        if not path:
            if not silent:
                print("IFC.TopologiesByPath - Error: the input path parameter is not a valid path. Returning None.")
            return None
        try:
            file = ifcopenshell.open(path)
        except:
            file = None
        if not file:
            if not silent:
                print("IFC.TopologiesByPath - Error: the input file parameter is not a valid file. Returning None.")
            return None
        return IFC.TopologiesByFile(file,
                             includeTypes=includeTypes,
                             excludeTypes=excludeTypes,
                             dictionaryMode=dictionaryMode,
                             clean=clean,
                             epsilon=epsilon,
                             angTolerance=angTolerance,
                             tolerance=tolerance,
                             silent=silent)


    @staticmethod
    def ElementTypes(file, includeCounts: bool = False, silent: bool = False):
        """
        Returns the IFC element/entity types found in the input IFC file, sorted alphabetically.

        Parameters
        ----------
        file : ifcopenshell.file
            The input IFC file.
        includeCounts : bool , optional
            If set to True, the method returns a list of dictionaries with each IFC type
            and its occurrence count. If set to False, it returns a list of IFC type names.
            Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            If includeCounts is False, returns a sorted list of IFC entity type names.
            If includeCounts is True, returns a sorted list of dictionaries in the form:
            [{"type": "IfcWall", "count": 12}, ...]
        """

        try:
            import ifcopenshell
        except Exception:
            if not silent:
                print("IFC.ElementTypes - Error: Could not import ifcopenshell. Please install it first. Returning None.")
            return None

        if file == None:
            if not silent:
                print(f"IFC.ElementTypes - Error: Could not open the input IFC file. {e} Returning None.")
            return None

        try:
            type_counts = {}

            for element in file:
                try:
                    element_type = element.is_a()
                    type_counts[element_type] = type_counts.get(element_type, 0) + 1
                except Exception:
                    continue

            if includeCounts:
                return [
                    {"type": key, "count": type_counts[key]}
                    for key in sorted(type_counts.keys(), key=lambda x: x.lower())
                ]

            return sorted(type_counts.keys(), key=lambda x: x.lower())

        except Exception as e:
            if not silent:
                print(f"IFC.ElementTypes - Error: Could not retrieve IFC element types. {e} Returning None.")
            return None

    @staticmethod
    def ExportReferenceView(
        model: Any,
        path: str,
        schema: str = "IFC4",
        mvd: str = "RV1.2",
        project_name: str = "TopologicPy Project",
        site_name: str = "Default Site",
        building_name: str = "Default Building",
        storey_name: str = "Level 0",
        length_unit: str = "METRE",
        angle_unit: str = "RADIAN",
        area_unit: str = "SQUARE_METRE",
        volume_unit: str = "CUBIC_METRE",
        use_sweeps: bool = True,
        use_tessellation_fallback: bool = True,
        transfer_dictionaries: bool = True,
        validate: bool = True,
        silent: bool = False,
    ) -> str:
        """
        Export a TopologicPy-authored model to an IFC4 Reference View-compatible IFC.

        Parameters
        ----------
        model : object
            A TopologicPy structure representing a BIM model. For this starter skeleton,
            this is expected to be either:
            - a TopologicPy Graph that contains "element nodes" with dictionaries, or
            - a list/dict of element records you pass through your own adapter.
        path : str
            Output IFC file path.
        schema : str, optional
            IFC schema identifier (default "IFC4").
        mvd : str, optional
            Model View Definition label (default "RV1.2"). Used for intent/metadata.
        project_name, site_name, building_name, storey_name : str
            Spatial structure names.
        length_unit, angle_unit, area_unit, volume_unit : str
            IFC units.
        use_sweeps : bool
            Attempt swept solid representations where possible.
        use_tessellation_fallback : bool
            If sweeps fail / are unavailable, tessellate geometry.
        transfer_dictionaries : bool
            Transfer Topologic dictionaries into IFC properties (simple mapping).
        validate : bool
            Run basic IFC validation hooks after writing.
        silent : bool
            If True, suppress warnings.

        Returns
        -------
        str
            The output path.
        """
        cfg = IFCExportConfig(
            schema=schema,
            mvd=mvd,
            project_name=project_name,
            site_name=site_name,
            building_name=building_name,
            storey_name=storey_name,
            units={
                "length": length_unit,
                "angle": angle_unit,
                "area": area_unit,
                "volume": volume_unit,
            },
            use_sweeps=use_sweeps,
            use_tessellation_fallback=use_tessellation_fallback,
            transfer_dictionaries=transfer_dictionaries,
            validate=validate,
            silent=silent,
        )

        exporter = IFCReferenceViewExporter(cfg)
        exporter.export(model=model, path=path)
        return path
    
    @staticmethod
    def FileByPath(path: str, silent: bool = False):
        """
        Returns the IFC file object found at the input path.

        Parameters
        ----------
        path : str
            The input path to the IFC file.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        file
            The IFC file object.
        """

        try:
            import ifcopenshell
        except Exception:
            if not silent:
                print("IFC.FileByPath - Error: Could not import ifcopenshell. Please install it first. Returning None.")
            return None
        ifc_file = ifcopenshell.open(path)
        if not ifc_file:
            if not silent:
                print("IFC.FileByPath - Error: Could not open the IFC file. Returning None.")
            return None
        return ifc_file
    
    @staticmethod
    def RelationshipTypes(file, includeCounts: bool = False, silent: bool = False):
        """
        Returns the IFC relationship entity types found in the input IFC file, sorted alphabetically.

        Parameters
        ----------
        file : ifcopenshell.file
            The input IFC file.
        includeCounts : bool , optional
            If set to True, the method returns a list of dictionaries with each IFC
            relationship type and its occurrence count. If set to False, it returns
            a list of IFC relationship type names. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            If includeCounts is False, returns a sorted list of IFC relationship type names.
            If includeCounts is True, returns a sorted list of dictionaries in the form:
            [{"type": "IfcRelAggregates", "count": 12}, ...]
        """

        import os

        try:
            import ifcopenshell
        except Exception:
            if not silent:
                print("IFC.RelationshipTypes - Error: Could not import ifcopenshell. Please install it first. Returning None.")
            return None

        try:
            type_counts = {}

            for element in file:
                try:
                    element_type = element.is_a()

                    # IFC relationship entities conventionally derive from IfcRelationship
                    # and are named IfcRel...
                    if element_type.startswith("IfcRel"):
                        type_counts[element_type] = type_counts.get(element_type, 0) + 1

                except Exception:
                    continue

            if includeCounts:
                return [
                    {"type": key, "count": type_counts[key]}
                    for key in sorted(type_counts.keys(), key=lambda x: x.lower())
                ]

            return sorted(type_counts.keys(), key=lambda x: x.lower())

        except Exception as e:
            if not silent:
                print(f"IFC.RelationshipTypes - Error: Could not retrieve IFC relationship types. {e} Returning None.")
            return None
    
    @staticmethod
    def RelationshipTypesByGlobalId(file,
                                    globalId: str,
                                    includeCounts: bool = False,
                                    includeRelationshipIds: bool = False,
                                    silent: bool = False):
        """
        Returns the IFC relationship entity types associated with the IFC element
        identified by the input GlobalId, sorted alphabetically.

        Parameters
        ----------
        file : file
            The input IFC file.
        globalId : str
            The IFC GlobalId of the target element.
        includeCounts : bool , optional
            If set to True, the method returns a list of dictionaries with each
            relationship type and its occurrence count. If set to False, it returns
            a list of relationship type names. Default is False.
        includeRelationshipIds : bool , optional
            If set to True, the returned dictionaries include the GlobalIds of the
            matching relationship entities where available. This option implies
            includeCounts=True. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            If includeCounts and includeRelationshipIds are both False, returns a
            sorted list of IFC relationship type names.

            If includeCounts is True, returns a sorted list of dictionaries in the form:
            [{"type": "IfcRelDefinesByProperties", "count": 3}, ...]

            If includeRelationshipIds is True, returns:
            [{"type": "IfcRelDefinesByProperties", "count": 3, "globalIds": [...]}, ...]
        """

        import os

        if not isinstance(globalId, str) or len(globalId.strip()) < 1:
            if not silent:
                print("IFC.RelationshipTypesByGlobalId - Error: The input globalId parameter is not a valid string. Returning None.")
            return None

        try:
            import ifcopenshell
        except Exception:
            if not silent:
                print("IFC.RelationshipTypesByGlobalId - Error: Could not import ifcopenshell. Please install it first. Returning None.")
            return None


        try:
            element = file.by_guid(globalId.strip())
        except Exception:
            element = None

        if element is None:
            if not silent:
                print(f"IFC.RelationshipTypesByGlobalId - Error: Could not find an IFC element with GlobalId '{globalId}'. Returning None.")
            return None

        try:
            relationship_data = {}

            # get_inverse(element) returns all IFC entities that reference this element.
            # IFC relationship entities conventionally derive from IfcRelationship
            # and are named IfcRel...
            for inverse in file.get_inverse(element):
                try:
                    rel_type = inverse.is_a()
                except Exception:
                    continue

                if not isinstance(rel_type, str) or not rel_type.startswith("IfcRel"):
                    continue

                if rel_type not in relationship_data:
                    relationship_data[rel_type] = {
                        "count": 0,
                        "globalIds": []
                    }

                relationship_data[rel_type]["count"] += 1

                if includeRelationshipIds:
                    try:
                        rel_guid = getattr(inverse, "GlobalId", None)
                        if rel_guid:
                            relationship_data[rel_type]["globalIds"].append(rel_guid)
                    except Exception:
                        pass

            sorted_types = sorted(relationship_data.keys(), key=lambda x: x.lower())

            if includeRelationshipIds:
                return [
                    {
                        "type": rel_type,
                        "count": relationship_data[rel_type]["count"],
                        "globalIds": sorted(relationship_data[rel_type]["globalIds"], key=lambda x: x.lower())
                    }
                    for rel_type in sorted_types
                ]

            if includeCounts:
                return [
                    {
                        "type": rel_type,
                        "count": relationship_data[rel_type]["count"]
                    }
                    for rel_type in sorted_types
                ]

            return sorted_types

        except Exception as e:
            if not silent:
                print(f"IFC.RelationshipTypesByGlobalId - Error: Could not retrieve IFC relationship types. {e} Returning None.")
            return None